import logo from './logo.svg';
import './App.css';
import FileUploadComponent from "./FileUploadComponent "
function App() {
  return (
    <div className="App">
       <FileUploadComponent />
    </div>
  );
}

export default App;
